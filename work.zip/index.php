
<!DOCTYPE html>
<html>
<head>

	<title>Translation</title>
	<style >
		table{top margin=-20px; left margin=30px; right margin=500px;font-size:15px;

		}
		th{ background-color: grey;
			font-family:verdana;
			color:pink;
	
		}
		body {
  display:flex; flex-direction:column; justify-content:center;
  min-height:100vh;
  background-image: url('opop.jpg');
  background-repeat: no-repeat;
  background-size: cover;
}	
table {
	background-color:FFFFF0;
	 width:"50%" ;
	 cellspacing:"20";
	  border:"0";
}
p{
	color: black;
	font-family: verdana;
	 font-size: 25px;
}
	</style>
	<link rel="shortcut icon"  href="icon.jfif">
</head>
<body><center>	<p >Welcome to translation page</p>
	 
		<form method="post">
			
       
 
			<table   >
				<tr ><td colspan="2"><h1 style=" font-family:algerian;color: grey; text-align: center;"> Translation form</h1></tr>
	<tr>			
	<td>Translating :</td>
	<td><!-- <select name="status" id="status" onchange="sayIt()">
				<option name="gura">V_Gura</option>
				<option name="tuma">V_Rangura</option>
				<option name="rangura">V_Gurisha</option>
				<option name="Gurisha">V_Tuma</option>
				
			</select> -->
			 <select name="word">
    <option value="0">-- Select word --</option>
    <?php
        include "conn.php";  // Using database connection file here
        $records = mysqli_query($db, "SELECT * From indimi");  // Use select query here 

        while($data = mysqli_fetch_array($records))
        {
            echo "<option value='". $data['id'] ."'>" .$data['variable'] ."</option>";  // displaying data in option menu
        }	
    ?>  
  </select>
			</td>
			<td>To :</td>
			<td>
				<select name="status">
			    <option value="0">-- Select language --</option>
				<option value="1">Kinyarwanda</option>
				<option value="2">French</option>
				<option value="3">English</option>
				<option value="4">Swahili</option>
				
			</select></td>
			<td>
                  <button name="translate" style="color: black;border-color: white;border-style:dashed;padding: 12px;background-color: light;">Translate</button>
                   </td>
     </tr>
     <tr>
		 <?php 
		 $result=[];
		 if(isset($_POST['translate']))
		 {	
			$result[0] = " ";
			 $language = $_POST['status'];
			 $word = $_POST['word'];
			 if(($language == 0) || ($word == 0))
			 {
				 $result[0] = "choose valid data";

			 }
			 else {
				$query_select_indimi= mysqli_query($db, "SELECT * FROM indimi where id='$word'");
				if(mysqli_num_rows($query_select_indimi) > 0)
				{
					$result[0] = "one element found";

					$data_re = $query_select_indimi->fetch_array();

			if($language == 1)
			{
				$result[0] = $data_re['kinyarwanda'];
			}
			else if ($language == 2)
			{
				$result[0] = $data_re['french'];
			}	else if ($language == 3)
			{
				$result[0] = $data_re['english'];
			}	else if ($language == 4)
			{
				$result[0] = $data_re['swahili'];
			}
			else{
				$result[0]="couldn't find";
			}
				}
				else{
					$result[0] = "no element found";
				}

			 }

			
	
				
			

		
?> 
  <td>Here is your Result</td><td><label></label><?php echo $result[0];?></td><?php
		 }

		 
		 ?>
   
    
     </tr>

          
                   
</table>
<!-- <label name="selected" id="selected">hjjfj</label>
 <script>
 function sayIt(){
	const variable=document.getElementById("status").value;
	document.getElementsByName("selected").value=variable;
	return variable;
}

// </script>-->
</body>
</html>			


